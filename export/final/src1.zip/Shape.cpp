#include "Shape.h"

#ifndef JPORTA
SDL_Renderer* Shape::debugRenderer = nullptr;

bool DragAndDrop::isDragging = false;
#endif // !JPORTA

