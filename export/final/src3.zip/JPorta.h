#pragma once
//#define MEMTRACE
#define JPORTA